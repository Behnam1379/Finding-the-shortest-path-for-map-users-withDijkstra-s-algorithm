class Edge:

    # Constructor
    def __init__(self, head, tail):
        self.__head = int(head)
        self.__tail = int(tail)

    # getter head
    def get_head(self):
        return self.__head

    # getter tail
    def get_tail(self):
        return self.__tail

    # return long of street
    def get_wieght(self):
        return self.__tail**2 + self.__head**2
